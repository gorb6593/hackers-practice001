<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-09
 * Time: 오후 4:24
 */
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$nm = $_POST['id33'];
//실행할 쿼리
$sql_select = "SELECT * FROM lec WHERE category_name = '$nm'";

$result_lecture2 = mysqli_query($conn, $sql_select);

//db연결 종료
mysqli_close();

//result값 출력
$row_lecture2 = mysqli_fetch_array($result_lecture2);

if(isset($row['id33'])){
    echo false;
}else{
    echo true;
}

exit;