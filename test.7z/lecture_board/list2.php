<?php include $_SERVER['DOCUMENT_ROOT']."/lecture_board/header.php";
include $_SERVER['DOCUMENT_ROOT']."/lecture_board/list_proc2.php";
$id = $_SESSION['userId'];
?>

            <form action="index.php" method="get">
                <input type="hidden" name="mode" value="list2">
            <div class="search-info">
                <div class="search-form f-r">
                    <select class="input-sel" name="ctg_name" style="width:158px">일반직무/산업직무/공통역량/어학 및 자격증
                        <?php
                        while ($row_ctg = mysqli_fetch_array($result_ctg)) {
                            ?>
                            <option value="<?php print $row_ctg['category_number']; ?>"><?php print $row_ctg['category_name']; ?></option>
                            <?php
                        }
                        ?>
                    </select>
                    <select class="input-sel" name="ctg_name2" style="width:158px">
                        <option value="lec_title">강의명</option>
                        <option value="writer">작성자</option>
                    </select>
                    <input type="text" class="input-text" name="search" id="search" placeholder="강의명 입력" style="width:158px"/>
                    <input type="submit" value="검색" class="btn-s-dark">
                </div>
            </div>
            </form>
            <table border="0" cellpadding="0" cellspacing="0" class="tbl-bbs">
                <caption class="hidden">수강후기</caption>
                <colgroup>
                    <col style="width:8%"/>
                    <col style="width:8%"/>
                    <col style="*"/>
                    <col style="width:15%"/>
                    <col style="width:12%"/>
                    <col style="width:12%"/>
                </colgroup>

                <thead>
                <tr>
                    <th scope="col">번호</th>
                    <th scope="col">분류</th>
                    <th scope="col">제목</th>
                    <th scope="col">강좌만족도</th>
                    <th scope="col">조회수</th>
                    <th scope="col">작성자</th>
                </tr>
                </thead>

                <tbody>

                <!-- set -->
                <?php
                if(isset($_REQUEST["page"])){
                    $page = $_REQUEST["page"];
                }else{
                    $page = 1;
                }

                //전체 글 수
                $total_record = mysqli_num_rows($result);

                //한 화면에 표시되는 글 수
                $scale = 20;

                //전체 페이지 수 계산
                if(($total_record % $scale) == 0){
                    $total_page = floor($total_record/$scale);
                }else{
                    $total_page = floor($total_record/$scale) + 1;
                }

                //표시할 페이지에 따라 $start 계산
                $start =(intval($page)-1) * $scale;

                $number = $total_record - $start;

                if($page == 1) {
                    ?>
                    <?php
                    while ($row_top3 = mysqli_fetch_array($result_top3)) {
                        ?>
                        <tr class="bbs-sbj">
                            <td><span class="txt-icon-line"><em>BEST</em></span></td>
                            <td><?php echo $row_top3['category']; ?></td>
                            <td>
                                <a href="http://test.hackers.com/lecture_board/view.php?num=<?php print $row_top3['no'].'&num2='.$row_top3['lec_number']?>">
                                    <span class="tc-gray ellipsis_line">수강 강의명 : <?php print $row_top3['lec_title']?></span>
                                    <strong class="ellipsis_line"><?php print $row_top3['rev_title'] ?></strong>
                                </a>
                            </td>
                            <td><?php print $row_top3['grade'] ?></td>
                            <td><?php print $row_top3['view_cnt'] ?></td>
                            <td class="last"><?php print $row_top3['writer']; ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                    <?php
                }

                for($i=$start; $i<$start+$scale && $i<$total_record; $i++){
                    mysqli_fetch_assoc($result, $i);
                    $row = mysqli_fetch_assoc($result);

                    $num = $row['no'];
                    $num2 = $row['lec_number'];
                    $category = $row['category_number'];
                    $lec_title = $row['lec_title'];
                    $rev_title = $row['rev_title'];
                    $grade = $row['grade'];
                    $writer = $row['writer'];
                    $view_cnt = $row['view_cnt'];
                    $reg_dtm  = $row['reg_dtm'];

                    ?>

                    <tr class="bbs-sbj">
                        <td><?php print $total_record-$i ?></td>
                        <td><?php print $category ?></td>
                        <td>
                            <a href="http://test.hackers.com/lecture_board/view.php?num=<?php print $num.'&num2='.$ro  ?>">
                                <span class="tc-gray ellipsis_line">수강 강의명 : <?php print $lec_title?></span>
                                <strong class="ellipsis_line">수강 후기 제목 : <?php print $rev_title ?></strong>
                            </a>
                        </td>
                        <td><?php print $grade ?></td>
                        <td><?php print $view_cnt ?></td>
                        <td class="last"><?php print $writer ?></td>

                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>

            <div class="box-paging">
                <a href="list2.php?page=1">◀◀</a>
                <?php
                if($total_page>=2 && $page>=2){
                    $new_page = $page-1;
                    ?>
                    <a href="list2.php?page=<?php print $new_page?>">◀</a>
                    <?php
                }

                //게시판 목록 하단에 페이지 링크 번호 출력
                for($i=1; $i<=$total_page; $i++){
                    if($page==$i){
                        ?>
                        <a href="list2.php?page=<?php print $new_page?>"><?php print $i?></a>
                        <?php
                    }else{
                        ?>
                        <a href='list2.php?page=<?php print $i?>'><?php print $i?></a>
                        <?php
                    }

                }

                if($total_page >= 2 && $page != $total_page){
                    $new_page = $page + 1;
                    ?>
                    <a href="list2.php?page=<?php print $new_page?>">▶</a>
                <?php
                }else{
                    ?>
                    <a href='list2.php?page=<?php print $i?>'><?php print $i?></a>
                    <?php
                }

                ?>
                <a href="list2.php?page=<?php print $total_page?>">▶▶</a>
            </div>

            <div class="box-btn t-r">
                <a href="index.php?mode=write" class="btn-m">후기 작성</a>

            </div>
        </div>
    </div>
<script>
    $(function() {
        $(document).ready(function() {
            $('select[name=ctg_name2]').change(function() {
                if($(this).val()=="lec_title"){
                    $('#search').attr("placeholder", "강의명 입력");
                }else{
                    $('#search').attr("placeholder", "강사명 입력");
                }
            });
        });
    });
</script>
<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
