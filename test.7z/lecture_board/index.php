<?php
session_start();
$mode = $_REQUEST['mode'];

$file_name = $mode.".php";

if($mode == 'write'){
    $id = $_SESSION['userId'];

    if(!isset($id)){
        echo "<script>alert('로그인 후 이용가능합니다.'); location.href='http://test.hackers.com/member/login.html';</script>";
    }
}

if($mode == 'reply'){

    $id = $_SESSION['userId'];
    $category_number = $_POST['category_number'];
    $lecture_title = $_POST['lecture'];
    $review_title = $_POST['review'];
    $content = $_POST['content'];
    $grade = $_POST['grade'];

    echo $id." id"."<br>";
    echo $category." ct"."<br>";
    echo $lecture_title." lec_title"."<br>";
    echo $review_title." rev_title"."<br>";
    echo $grade." grade"."<br>";
    echo $content." content"."<br>";
    //db 연결
    include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

    $sql_insert = "INSERT INTO
                           rev_lec (category_number
                                   ,lec_title
                                   ,rev_title
                                   ,grade
                                   ,content
                                   ,writer)
                           VALUES ('$category_number'
                                  ,'$lecture_title'
                                  ,'$review_title'
                                  ,'$grade'
                                  ,'$content'
                                  ,'$id')";
    mysqli_query($conn,$sql_insert);
    mysqli_close();
   // echo "<script>alert('후기 등록 완료'); location.href='http://test.hackers.com/lecture_board/index.php?mode=list2';</script>";
    //echo "<script>history.back();</script>";
}

include_once $file_name;
