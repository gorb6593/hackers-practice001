<?php include $_SERVER['DOCUMENT_ROOT']."/lecture_board/header.php";

include $_SERVER['DOCUMENT_ROOT']."/lecture_board/list_proc.php";

$id = $_SESSION['userId'];


?>

            <form action="index.php?mode=search.php" method="post">
            <div class="search-info">
                <div class="search-form f-r">

                        <input type="hidden" name="mode" value="search"/>
                    <select class="input-sel" style="width:158px">일반직무/산업직무/공통역량/어학 및 자격증
                        <?php
                        while ($row_category = mysqli_fetch_array($result_category)) {
                            ?>
                            <option value="<?php echo $row_category['category_name']; ?>"><?php echo $row_category['category_name']; ?></option>
                            <?php
                        }
                        ?>
                    </select>
                    <select class="input-sel" style="width:158px">
                        <option value="">강의명</option>
                        <option value="">작성자</option>
                    </select>
                    <input type="text" class="input-text" placeholder="강의명을 입력하세요." style="width:158px"/>
                    <input type="submit" value="검색" class="btn-s-dark">
                </div>
            </div>
            </form>
            <table border="0" cellpadding="0" cellspacing="0" class="tbl-bbs">
                <caption class="hidden">수강후기</caption>
                <colgroup>
                    <col style="width:8%"/>
                    <col style="width:8%"/>
                    <col style="*"/>
                    <col style="width:15%"/>
                    <col style="width:12%"/>
                </colgroup>

                <thead>
                <tr>
                    <th scope="col">번호</th>
                    <th scope="col">분류</th>
                    <th scope="col">제목</th>
                    <th scope="col">강좌만족도</th>
                    <th scope="col">작성자</th>
                </tr>
                </thead>

                <tbody>

                <!-- set -->
                <?php
                    if($_GET[mode] =='list') {
                        ?>
                        <?php
                        while ($row = mysqli_fetch_array($result)) {
                            ?>
                            <tr class="bbs-sbj">
                                <td><span class="txt-icon-line"><em>BEST</em></span></td>
                                <td><?php echo $row['category']; ?></td>
                                <td>
                                    <a href="view.php?no=<?php echo $row['lec_number']?>">
                                        <span class="tc-gray ellipsis_line">수강 강의명 : <?php print $row['lec_title'] ?></span>
                                        <strong class="ellipsis_line"><?php print $row['rev_title'] ?></strong>
                                    </a>
                                </td>
                                <td>
                            <span class="star-rating">
                                <span class="star-inner" style="width:80%"></span>

                            </span>
                                    </td>
                                    <td class="last"><?php echo $row['writer']; ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                        <?php
                    }
                ?>
                <?php
                 $count = 1;
                 while($row = mysqli_fetch_array($result3)) {
                     ?>
                     <tr class="bbs-sbj">
                         <td><span><em><?php print $count ?></em></span></td>
                         <td><?php echo $row['category']; ?></td>
                         <td>
                             <a href="#">
                                 <span class="tc-gray ellipsis_line">수강 강의명 : <?php print $row['lec_title'] ?></span>
                                 <strong class="ellipsis_line"><?php print $row['rev_title'] ?></strong>
                             </a>
                         </td>
                         <td>
						<span class="star-rating">
							<span class="star-inner" style="width:80%"></span>
						</span>
                         </td>
                         <td class="last"><?php echo $row['writer']; ?></td>
                     </tr>

                     <?php
                     $count = $count + 1;
                 }
                ?>
                </tbody>
            </table>

            <div class="box-paging">
                <a href="list.php?page=list"><i class="icon-first"><span class="hidden">첫페이지</span></i></a>

                <?php
                /* paging : 이전 페이지 */
                if($page <= 1){
                    ?>
                    <a href="list.php?page=1"><i class="icon-prev"><span class="hidden">이전페이지</span></i></a>
                <?php } else{ ?>
                    <a href="list.php?page=<?php echo ($page-1); ?>"><i class="icon-prev"><span class="hidden">이전페이지</span></i></a>
                <?php };?>

                <?php
                /* pager : 페이지 번호 출력 */
                for($print_page = $s_pageNum; $print_page <= $e_pageNum; $print_page++){
                    ?>
                    <a href="list.php?page=<?php echo $print_page; ?>"><?php echo $print_page; ?></a>
                <?php };?>

                <?php
                /* paging : 다음 페이지 */
                if($page >= $total_page){
                    ?>
                    <a href="list.php?page=<?php echo $total_page; ?>"><i class="icon-next"><span class="hidden">다음페이지</span></i></a>
                <?php } else{ ?>
                    <a href="list.php?page=<?php echo ($page+1); ?>"><i class="icon-next"><span class="hidden">다음페이지</span></i></a>
                <?php };?>
                <!--
                <a href="#"><i class="icon-first"><span class="hidden">첫페이지</span></i></a>
                <a href="#"><i class="icon-prev"><span class="hidden">이전페이지</span></i></a>
                <a href="#" class="active">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <a href="#">5</a>
                <a href="#">6</a>
                <a href="#"><i class="icon-next"><span class="hidden">다음페이지</span></i></a>
                <a href="#"><i class="icon-last"><span class="hidden">마지막페이지</span></i></a>
                -->
                <a href="list.php?page=-1"><i class="icon-last"><span class="hidden">마지막페이지</span></i></a>
            </div>

            <div class="box-btn t-r">
                <a href="index.php?mode=write" class="btn-m">후기 작성</a>

            </div>
        </div>
    </div>

<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
