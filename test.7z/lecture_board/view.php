<?php include $_SERVER['DOCUMENT_ROOT']."/lecture_board/header.php";

include $_SERVER['DOCUMENT_ROOT']."/lecture_board/view_proc.php";
?>
            <table border="0" cellpadding="0" cellspacing="0" class="tbl-bbs-view">
                <caption class="hidden">수강후기</caption>
                <colgroup>
                    <col style="*"/>
                    <col style="width:20%"/>
                </colgroup>
                <tbody>
                <tr>
                    <th scope="col">제목 : <?php print $reply['rev_title']?></th>
                    <th scope="col" class="user-id">작성자 | <?php print $reply['writer']?></th>
                </tr>
                <tr>
                    <td colspan="2">
                        <div class="box-rating">
                            <span class="tit_rating">강의만족도 : <?php print $reply['grade']?></span>

                        </div>

                        <?php print $reply['rev_content']?>
                    </td>
                </tr>
                </tbody>
            </table>


            <p class="mb15"><strong class="tc-brand fs16"><?php print $reply['writer']?>님의 수강하신 강의 정보</strong></p>

            <table border="0" cellpadding="0" cellspacing="0" class="tbl-lecture-list">
                <caption class="hidden">강의정보</caption>
                <colgroup>
                    <col style="width:166px"/>
                    <col style="*"/>
                    <col style="width:110px"/>
                </colgroup>
                <tbody>
                <tr>
                    <td>
                        <a href="#" class="sample-lecture">
                            <img src="http://test.hackers.com/admin/img/<?php print $reply2['file_copied']?>" alt="" width="144" height="101" />
                            <span class="tc-brand">샘플 강의 ▶</span>
                        </a>
                    </td>
                    <td class="lecture-txt">
                        <em class="tit mt10">강의명: <?php print $reply['lec_name']?></em>
                        <p class="tc-gray mt20">강사: <?php print $reply['teacher']?> | 학습난이도 : <?php print $reply2['level']?> | 교육시간: 1<?php print $reply2['time']?></p>
                    </td>
                    <td class="t-r"><a href="#" class="btn-square-line">강의<br />신청</a></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>


<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
