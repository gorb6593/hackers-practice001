<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-10
 * Time: 오후 4:28
 */
//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$no = $_GET['num'];
$lec_number = $_GET['num2'];
$sql = "select * from rev_lec where no = '$no'";
$result = mysqli_query($conn, $sql) or die("쿼리 에러 :".mysqli_error($conn));
$reply = mysqli_fetch_array($result);

$sql2 = "SELECT * FROM lec WHERE lec_number = '$lec_number'";
$result2 = mysqli_query($conn, $sql2) or die("쿼리 에러 :".mysqli_error($conn));
$reply2 = mysqli_fetch_array($result2);

if(isset($no)){
    $count = $reply['view_cnt'] + 1;
    $sql3 = "UPDATE rev_lec SET view_cnt = '$count' WHERE NO = '$no'";
    $result3 = mysqli_query($conn, $sql3) or die("쿼리 에러 :".mysqli_error($conn));
}