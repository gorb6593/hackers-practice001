<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-08
 * Time: 오전 10:04
 */
//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$value1 = $_GET['ctg_name'];
$value2 = $_POST['ctg_name2'];
$value3 = $_POST['search'];


$sql = "select * from rev_lec ORDER BY no desc";
$result = mysqli_query($conn, $sql) or die("쿼리 에러 :" . mysqli_error($conn));

$sql_top3 = "SELECT * FROM rev_lec ORDER BY view_cnt DESC LIMIT 3";
$result_top3 = mysqli_query($conn, $sql_top3) or die("쿼리 에러 :" . mysqli_error($conn));

$sql_ctg = "SELECT * FROM lec_category";
$result_ctg = mysqli_query($conn, $sql_ctg) or die("쿼리 에러 :".mysqli_error($conn));

$category_search = $_POST['id'];
$sql_search = "SELECT * FROM rev_lec WHERE category_number= '$category_search'";
$result_search = mysqli_query($conn, $sql_search) or die("쿼리 에러 :".mysqli_error($conn));

//result값 출력
$row_search = mysqli_fetch_array($result_search);



