<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-08
 * Time: 오전 10:04
 */
//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$sql_123 = "select * from rev_lec";
$result_123 = mysqli_query($conn, $sql_123) or die("쿼리 에러 :".mysqli_error($conn));
$row123 = mysqli_fetch_array($result_123);
$total123 = $row123['total'];

//실행할 sql문
$sql_all = "select * from rev_lec";
$result_all = mysqli_query($conn, $page_all);

$page_total = mysqli_num_rows($result_all);
//$row_t = mysqli_query($conn, $page_total);


$sql_top3 = "SELECT * FROM rev_lec ORDER BY view_cnt DESC LIMIT 3";

$sql_20 = "SELECT * FROM rev_lec ORDER BY reg_dtm desc LIMIT 0, 20";
$result3 = mysqli_query($conn, $sql_20);
//result에 쿼리값 저장
$result = mysqli_query($conn, $sql_top3);





//db연결 종료
mysqli_close($conn);
