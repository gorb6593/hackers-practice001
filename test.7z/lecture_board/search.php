<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-08
 * Time: 오후 1:18
 */
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$category = $_POST['ctg_name'];

if($_POST['ctg_name2'] == 'writer'){
    $writer = $_POST['search'];
    echo $writer.'<br>';
    echo $category.'<br>';
    echo '111'.'<br>';
    $sql = "select * from rev_lec where category = '$category' and writer = '$writer'";
}elseif (($_POST['ctg_name2'] == 'lec_title')){
    $lec_title = $_POST['search'];
    echo '222'.'<br>';
    $sql = "select * from rev_lec where category = '$category' and lec_title = '$lec_title'";
}
echo '333'.'<br>';
$result_search = mysqli_query($conn, $sql) or die("쿼리 에러 :".mysqli_error($conn));

if(isset($result_search)) {
    return $result_search;
}