<?php include $_SERVER['DOCUMENT_ROOT']."/lecture_board/header.php";

$id = $_SESSION['userId'];
include $_SERVER['DOCUMENT_ROOT']."/admin/index_proc.php";
//include $_SERVER['DOCUMENT_ROOT']."/lecture_board/write_proc.php";
?>
            <div class="user-notice">
                <strong class="fs16">유의사항 안내</strong>
                <ul class="list-guide mt15">
                    <li class="tc-brand">수강후기는 신청하신 강의의 학습진도율 25%이상 달성시 작성가능합니다. </li>
                    <li>욕설(욕설을 표현하는 자음어/기호표현 포함) 및 명예훼손, 비방,도배글, 상업적 목적의 홍보성 게시글 등 사회상규에 반하는 게시글 및 강의내용과 상관없는 서비스에 대해 작성한 글들은 삭제 될 수 있으며, 법적 책임을 질 수 있습니다.</li>
                </ul>
            </div>
            <form method="post" action="index.php">
                <input type="hidden" name="mode" value="reply"/>
                <input type="hidden" name="category" value="<?php print '11'?>">
            <table border="0" cellpadding="0" cellspacing="0" class="tbl-col">
                <caption class="hidden">강의정보</caption>
                <colgroup>
                    <col style="width:15%"/>
                    <col style="*"/>
                </colgroup>

                <tbody>
                <tr>
                    <th scope="col">강의<?php print $_POST?></th>
                    <td>
                        <select class="input-sel ml5" name="lecture" style="width:454px">
                            <?php
                            while ($row_lec2 = mysqli_fetch_array($result_lec)) {
                                ?>
                                <option value="<?php echo $row_lec2['lec_name']; ?>"><?php echo "강의제목:".$row_lec2['lec_name'] ?></option>
                                <?php
                            }

                            ?>
                        </select>

                    </td>
                </tr>
                <tr>
                    <th scope="col">제목</th>
                    <td><input type="text" name="review" class="input-text" style="width:611px"/></td>
                </tr>
                <tr>
                    <th scope="col">강의만족도</th>
                    <td>
                        <select class="input-sel" name="grade" id="grade"  style="width:160px">
                            <option value="5">5</option>
                            <option value="4">4</option>
                            <option value="3">3</option>
                            <option value="2">2</option>
                            <option value="1">1</option>
                        </select>
                    </td>
                </tr>
                </tbody>
            </table>

            <div class="editor-wrap">
                <input type="text" name="content" class="input-text" placeholder="수강 후기 입력"/>

            </div>

            <div class="box-btn t-r">
                <a href="#" class="btn-m-gray">목록</a>

                <input type="submit" value="저장" class="btn-m ml5"/>
            </div>
            </form>


        </div>
    </div>
<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";

?>
</div>
</body>
</html>
