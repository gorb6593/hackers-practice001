<?php
include $_SERVER['DOCUMENT_ROOT']."/common/header.php";
//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$id = $_SESSION['userId'];

//실행할 쿼리
$sql_select = "select * from member where id = '$id'";

//result에 쿼리값 저장
$result = mysqli_query($conn, $sql_select);

//db연결 종료
mysqli_close();

//result값 출력
$row = mysqli_fetch_array($result);

$userNO = $row['no'];
$userNm = $row['name'];
$userId = $row['id'];
$userPw = $row['password'];
$emails = explode("@",$row['email']);
$email1 = $emails[0];
$email2 = $emails[1];
$tels = explode("-",$row['tel']);
$tel1 = $tels[0];
$tel2 = $tels[1];
$tel3 = $tels[2];
$phones = explode("-",$row['phone']);
$phone1 = $phones[0];
$phone2 = $phones[1];
$phone3 = $phones[2];
$postcode = $row['postcode'];
$address = $row['address'];
$detail_address = $row['detail_address'];


?>


    <form method="post" action="modify_check.php">
    <div id="container" class="container-full">
        <div id="content" class="content">
            <div class="inner">
                <div class="tit-box-h3">
                    <h3 class="tit-h3">내정보수정</h3>
                    <div class="sub-depth">
                        <span><i class="icon-home"><span>홈</span></i></span>
                        <strong>내정보수정</strong>
                    </div>
                </div>

                <div class="section-content">
                    <table border="0" cellpadding="0" cellspacing="0" class="tbl-col-join">
                        <caption class="hidden">강의정보</caption>
                        <colgroup>
                            <col style="width:15%"/>
                            <col style="*"/>
                        </colgroup>

                        <tbody>
                        <tr>
                            <th scope="col"><span class="icons">*</span>이름</th>
                            <td><input type="text" class="input-text" value="<?php echo $userNm?>" name="name" style="width:302px" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>아이디</th>
                            <td><input type="text" class="input-text" value="<?php echo $userId?>" name="id" style="width:302px" readonly required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>비밀번호</th>
                            <td><input type="password" class="input-text" value="<?php echo $userPw?>" name="password[]" style="width:302px" placeholder="8-15자의 영문자/숫자 혼합" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>비밀번호 확인</th>
                            <td><input type="password" class="input-text" value="<?php echo $userPw?>" name="password[]" style="width:302px" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>이메일주소</th>
                            <td>
                                <input type="text" class="input-text" value="<?php echo $email1?>" name="email[]" style="width:138px" required/> @ <input type="text" class="input-text" value="<?php echo $email2?>" name="email[]" style="width:138px" required/>
                                <select class="input-sel" style="width:160px">
                                    <option value="">www.naver.com</option>
                                    <option value="">구글</option>
                                    <option value="">다음</option>
                            
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>휴대폰 번호</th>
                            <td><input type="text" class="input-text" value="<?php echo $phone1?>" name="phone[]" style="width:88px" required/> - <input type="text" class="input-text" name="phone[]" value="<?php echo $phone2?>" style="width:88px" required/> - <input type="text" class="input-text" value="<?php echo $phone3?>" name="phone[]" style="width:88px" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons"></span>일반전화 번호</th>
                            <td><input type="text" class="input-text" value="<?php echo $tel1?>" name="tel[]" style="width:88px" required/> - <input type="text" class="input-text" value="<?php echo $tel2?>" name="tel[]" style="width:88px" required/> - <input type="text" class="input-text" value="<?php echo $tel3?>" name="tel[]" style="width:88px" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>주소</th>
                            <td>
                                <p >
                                    <label>우편번호 <input type="text" value="<?php echo $postcode?>" name="postcode" class="input-text ml5" style="width:242px" required /></label><a href="#" class="btn-s-tin ml10">주소찾기</a>
                                </p>
                                <p class="mt10">
                                    <label>기본주소 <input type="text" value="<?php echo $address?>" name="address" class="input-text ml5" style="width:719px" required/></label>
                                </p>
                                <p class="mt10">
                                    <label>상세주소 <input type="text" value="<?php echo $detail_address?>" name="detail_address" class="input-text ml5" style="width:719px" required/></label>
                                    <input type="hidden" name="no" value="<?php echo $userNO?>"/>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>SMS수신</th>
                            <td>
                                <div class="box-input">
                                    <label class="input-sp">
                                        <input type="radio" name="sms" value="Y" checked="checked"/>
                                        <span class="input-txt">수신함</span>
                                    </label>
                                    <label class="input-sp">
                                        <input type="radio" name="sms" value="N"/>
                                        <span class="input-txt">미수신</span>
                                    </label>
                                </div>
                                <p>SMS수신 시, 해커스의 혜택 및 이벤트 정보를 받아보실 수 있습니다.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>메일수신</th>
                            <td>
                                <div class="box-input">
                                    <label class="input-sp">
                                        <input type="radio" name="mail" value="Y" checked="checked"/>
                                        <span class="input-txt">수신함</span>
                                    </label>
                                    <label class="input-sp">
                                        <input type="radio" name="mail" value="N"/>
                                        <span class="input-txt">미수신</span>
                                    </label>

                                </div>
                                <p>메일수신 시, 해커스의 혜택 및 이벤트 정보를 받아보실 수 있습니다.</p>
                            </td>
                        </tr>
                        </tbody>
                    </table>

                    <div class="box-btn">
                        <input type="submit" value="정보수정" class="btn-l"/>
                        <a href="http://test.hackers.com" class="btn-l">취소하기</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
