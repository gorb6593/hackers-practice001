<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-03
 * Time: 오전 11:09
 */

$__username = 'front_local';
$__password = 'dfrontend*@78';
$__database = 'test';
$__master  = '14.49.30.84:30007';

$conn = new mysqli($__master,$__username,$__password,$__database);
?>