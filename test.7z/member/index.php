<?php
$mode = $_REQUEST['mode'];

$file_name = $mode.".php";

include_once $file_name;