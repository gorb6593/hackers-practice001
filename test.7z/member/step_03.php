<?php include $_SERVER['DOCUMENT_ROOT']."/common/header.php";

?>
<?php
$hp_no1 = $_POST['hp_no1'];
$hp_no2 = $_POST['hp_no2'];
$hp_no3 = $_POST['hp_no3'];
?>
    <div id="container" class="container-full">
        <div id="content" class="content">
            <div class="inner">
                <div class="tit-box-h3">
                    <h3 class="tit-h3">회원가입</h3>
                    <div class="sub-depth">
                        <span><i class="icon-home"><span>홈</span></i></span>
                        <strong>회원가입</strong>
                    </div>
                </div>

                <div class="join-step-bar">
                    <ul>
                        <li><i class="icon-join-agree"></i> 약관동의</li>
                        <li><i class="icon-join-chk"></i> 본인확인</li>
                        <li class="last on"><i class="icon-join-inp"></i> 정보입력</li>
                    </ul>
                </div>
                <div class="section-content">
                    <form method="POST" action="index.php" name="testform" onsubmit="return test()">
                    <input type="hidden" name="mode" value="regist"/>
                    <table border="0" cellpadding="0" cellspacing="0" class="tbl-col-join">
                        <caption class="hidden">강의정보</caption>
                        <colgroup>
                            <col style="width:15%"/>
                            <col style="*"/>
                        </colgroup>

                        <tbody>
                        <tr>
                            <th scope="col"><span class="icons">*</span>이름</th>
                            <td><input type="text" class="input-text" name="name"  style="width:302px" /></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>아이디</th>
                            <td><input type="text" class="input-text" name="id" style="width:302px" placeholder="영문자로 시작하는 4~15자의 영문소문자, 숫자" required/><input type="button" id="checkid" value="아이디 중복확인" class="btn-s-tin ml10"/>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>비밀번호</th>
                            <td><input type="password" class="input-text" name="password" style="width:302px" placeholder="8-15자의 영문자/숫자 혼합" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>비밀번호 확인</th>
                            <td><input type="password" class="input-text" name="password2" style="width:302px" required/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>이메일주소</th>
                            <td>
                                <input type="text" class="input-text" id="email1" name="email" style="width:138px" required/> @ <input type="text" id="email2" name="email2" class="input-text" style="width:138px" required/>
                                <select class="input-sel" name="emailSelection" style="width:160px">
                                    <option value="1" selected="selected">선택하세요</option>
                                    <option value="naver.com">naver.com</option>s
                                    <option value="google.com">google.com</option>
                                    <option value="daum.net">daum.net</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>휴대폰 번호</th>
                            <td>
                                <input type="text" class="input-text" style="width:50px" value="<?php echo $hp_no1?>" name="phone1" readonly required/> -
                                <input type="text" class="input-text" style="width:50px" value="<?php echo $hp_no2?>" name="phone2" readonly required/> -
                                <input type="text" class="input-text" style="width:50px" value="<?php echo $hp_no3?>" name="phone3" readonly required/>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons"></span>일반전화 번호</th>
                            <td><input type="text" class="input-text" name="tel1" style="width:88px"/> - <input type="text" class="input-text" name="tel2" style="width:88px"/> - <input type="text" class="input-text" name="tel3" style="width:88px"/></td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>주소</th>
                            <td>
                                <p >
                                    <label>우편번호 <input type="text" class="input-text ml5" name="postcode" style="width:242px" disabled /></label><a href="#" class="btn-s-tin ml10">주소찾기</a>
                                </p>
                                <p class="mt10">
                                    <label>기본주소 <input type="text" class="input-text ml5" name="address" style="width:719px" required/></label>
                                </p>
                                <p class="mt10">
                                    <label>상세주소 <input type="text" class="input-text ml5" name="detail_address" style="width:719px" required/></label>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>SMS수신</th>
                            <td>
                                <div class="box-input">
                                    <label class="input-sp">
                                        <input type="radio" name="sms" value="Y" checked="checked"/>
                                        <span class="input-txt">수신함</span>
                                    </label>
                                    <label class="input-sp">
                                        <input type="radio" name="sms" value="N" />
                                        <span class="input-txt">미수신</span>
                                    </label>
                                </div>
                                <p>SMS수신 시, 해커스의 혜택 및 이벤트 정보를 받아보실 수 있습니다.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="col"><span class="icons">*</span>메일수신</th>
                            <td>
                                <div class="box-input">
                                    <label class="input-sp">
                                        <input type="radio" name="mail" value="Y" checked="checked"/>
                                        <span class="input-txt">수신함</span>
                                    </label>
                                    <label class="input-sp">
                                        <input type="radio" name="mail" value="N" />
                                        <span class="input-txt">미수신</span>
                                    </label>
                                </div>
                                <p>메일수신 시, 해커스의 혜택 및 이벤트 정보를 받아보실 수 있습니다.</p>
                            </td>

                        </tr>
                        </tbody>
                    </table>
                    <div class="box-btn">
                        <input type="submit" name="submit" id="next" class="btn-l" value="회원가입"/>
                    </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

<script>
    var key = "N";
    $(function () {
        $("#next").click(function (e) {
            if(key != "Y"){
                alert("아이디 중복검사를 먼저 해주세요.");
                return false;
            }
        })
    })

    $(function () {
        $("#checkid").click(function (e) {
            e.preventDefault();
            var input_value = $("input[name='id']").val();

            if(!input_value) {
                alert("아이디를 입력해주세요.");
                $("input[name='id']").focus();
                return false;
            }



            $.ajax({
                url: "/member/id_check.php", // 클라이언트가 HTTP 요청을 보낼 서버의 URL 주소
                data: { "id": input_value },  // HTTP 요청과 함께 서버로 보낼 데이터
                method: "POST",  // HTTP 요청 메소드(GET, POST 등)
                success : function(result){

                    if(result){
                        key = "Y";
                        alert('사용가능한 아이디 입니다.');
                    } else {
                        alert('중복된 아이디 입니다.');
                    }
                }
            });
        });
    });


    function test() {

        var v = document.testform;

        if(v.password.value != v.password2.value){
            alert("비밀번호가 다릅니다.");
            return false;
        }
        return true;
    }

    $(function() {
        $(document).ready(function() {
            $('select[name=emailSelection]').change(function() {
                if($(this).val()=="1"){
                    alert("!!");
                    $('#email2').val("");
                    $('#email2').attr("readonly", false);
                }else{
                    $('#email2').val($(this).val());
                    $('#email2').attr("readonly", true);
                    alert("??");
                }
            });
        });
    });

</script>
<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
