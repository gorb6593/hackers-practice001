<?php include $_SERVER['DOCUMENT_ROOT']."/common/header.php";
?>
<?php
    $agree = $_POST['agree'];
    $agree2 = $_POST['agree2'];
    if(isset($agree2)){
        $agree[0] = 'on';
        $agree[1] = 'on';
    }

    if(!isset($agree[0]) || !isset($agree[1])){
        echo "<script>alert('약관동의는 필수입니다.');location.replace('index.php?mode=step_01');</script>";
        exit();
    }

    session_start();
    $_SESSION['certification'] = '123456';

?>
    <div id="container" class="container-full">
        <div id="content" class="content">
            <div class="inner">
                <div class="tit-box-h3">
                    <h3 class="tit-h3">회원가입</h3>
                    <div class="sub-depth">
                        <span><i class="icon-home"><span>홈</span></i></span>
                        <strong>회원가입 완료</strong>
                    </div>
                </div>

                <div class="join-step-bar">
                    <ul>
                        <li><i class="icon-join-agree"></i> 약관동의</li>
                        <li class="on"><i class="icon-join-chk"></i> 본인확인</li>
                        <li class="last"><i class="icon-join-inp"></i> 정보입력</li>
                    </ul>
                </div>

                <div class="tit-box-h4">
                    <h3 class="tit-h4">본인인증</h3>
                </div>
                <form method="POST" action="index.php" name="form1" onsubmit="return test()" >
                    <input type="hidden" name="mode" value="step_03"/>
                    <div class="section-content after">
                        <div class="identify-box" style="width:100%;height:190px;">
                            <div class="identify-inner">
                                <strong>휴대폰 인증</strong>
                                <p>주민번호 없이 메시지 수신가능한 휴대폰으로 1개 아이디만 회원가입이 가능합니다. </p>
                                <input type="text" class="input-text" name="hp_no1" style="width:50px" required/> -
                                <input type="text" class="input-text" name="hp_no2" style="width:50px" required/> -
                                <input type="text" class="input-text" name="hp_no3" style="width:50px" required/>
                                <input type="button" value="인증번호 받기" id="phoneCheck" class="btn-s-line"/>
                                <br /><br />

                                <input type="text" class="input-text" name="submit2" id="next2" style="width:200px" />
                                
                                <input type="submit" name="submit" class="btn-s-line" id="next" value="인증번호 확인"/>
                            </div>
                            <i class="graphic-phon"><span>휴대폰 인증</span></i>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<script>
    
    $(function () {
        $("#next").click(function ( ) {
            var value = $("input[name='submit2']").val();

            if(value == ""){
                alert("인증번호를 입력해주세요");
                return false;
            }
            if(value != "123456"){
                alert("인증번호가 틀렸습니다.");
                return false;
            }
            return true;
        });
    });
    
    $(document).ready(function () {
       $("#phoneCheck").on('click', function () {
            alert("인증번호는 123456입니다");
       });
    });

    function test() {

        var v = document.testform;

        if(v.submit2.valueOf() != 123456){
            alert("인증번호가 틀렸습니다.");
            return false;
        }


        return true;
    }

</script>
<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
