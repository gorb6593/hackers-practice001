<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-03
 * Time: 오후 5:54
 */
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";
$id = $_POST['id'];

//실행할 쿼리
$sql_select = "select * from member where id = '$id'";

$result = mysqli_query($conn, $sql_select);

//db연결 종료
mysqli_close();

//result값 출력
$row = mysqli_fetch_array($result);

if(isset($row['id'])){
    echo false;
}else{
    echo true;
}

exit;