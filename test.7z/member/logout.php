<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-03
 * Time: 오후 4:43
 */
session_start();
session_destroy();

header("Location: http://test.hackers.com");
exit();
?>