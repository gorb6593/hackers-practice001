<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-03
 * Time: 오전 10:49
 */

//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

/*
//db접속 정보
$__username = 'front_local';
$__password = 'dfrontend*@78';
$__database = 'test';
$__master  = '14.49.30.84:30007';


$conn = new mysqli($__master,$__username,$__password,$__database);
*/
$id = $_POST['userId'];
$pw = $_POST['userPw'];

//실행할 쿼리
$sql_select = "select * from member where id = '$id' and password = sha2('$pw', 256)";

//result에 쿼리값 저장
$result = mysqli_query($conn, $sql_select);

//db연결 종료
mysqli_close();

//result값 출력
$row = mysqli_fetch_array($result);

if($id == '' || $pw == ''){
    echo "<script>alert('아이디와 비밀번호를 입력해주세요.');location.href='http://test.hackers.com/member/login.html';</script>";
}

if(!isset($row['id'])){
    echo "<script>alert('로그인 실패');location.href='http://test.hackers.com/member/login.html';</script>";
    exit();
}

if($row['id'] == $_POST['userId']){
    //세션 시작
    session_start();


    $userId = $row['id'];
    $_SESSION['userId'] = $userId;

    //메인화면으로 리다이렉트
    echo "<script>location.href='http://test.hackers.com/';</script>";
    exit();
}
?>
