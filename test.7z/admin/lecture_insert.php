<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-10
 * Time: 오전 9:53
 */

//세션 시작
session_start();

//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

//설정 값들
$id = $_SESSION['userId'];
$lec_name = $_POST['lec_name'];
$category_number = $_POST['categorySelection'];
$regist_day = date("Y-m-d-H-i-s");
$teacher = $_POST['teacher'];
$level = $_POST['level'];
$time = $_POST['time'];


$upload_dir = './img/';

$upfile_name = $_FILES["upfile"]["name"];
$upfile_tmp_name = $_FILES["upfile"]["tmp_name"];
$upfile_type = $_FILES["upfile"]["type"];
$upfile_size = $_FILES["upfile"]["size"];
$upfile_error = $_FILES["upfile"]["error"];

$type = explode("/", $upfile_type);
$extStatus = false;
switch($type[1]){
    case 'jpeg':
    case 'jpg':
    case 'gif':
    case 'bmp':
    case 'png':
        $extStatus = true;
        break;

    default:
        echo "이미지 전용 확장자(jpg, bmp, gif, png)외에는 사용이 불가합니다.";
        exit;
        break;
}

if($upfile_name && !$upfile_error){

    $file = explode(".", $upfile_name);
    $file_name = $file[0];
    $file_ext = $file[1];

    $copied_file_name = date("Y_m_d_H_i_s");
    $copied_file_name .= ".".$file_ext;

    $upload_file = $upload_dir.$copied_file_name;
    if ($upfile_size > 10000000){
        echo "<script>alert('용량 초과'); history.go(-1) </script>";
        exit;
    }
    if(!move_uploaded_file($upfile_tmp_name, $upload_file)){
        echo "<script>alert('파일 저장 실패'); history.go(-1) </script>";
        exit;
    }
}else{
    $upfile_name = "";
    $upfile_type = "";
    $copied_file_name = "";
}

echo '<br>'.'$category_number: '.$category_number;
echo '<br>'.'$id: '.$id;
echo '<br>'.'$lec_name: '.$lec_name;
echo '<br>'.'$regist_day: '.$regist_day;
echo '<br>'.'$upload_dir: '.$upload_dir;
echo '<br>'.'$upfile_name: '.$upfile_name;
echo '<br>'.'$upfile_type: '.$upfile_type;
echo '<br>'.'$copied_file_name: '.$copied_file_name;
echo '<br>'.'teacher: '.$teacher;
echo '<br>'.'$level: '.$level;
echo '<br>'.'$time: '.$time;


$sql = "INSERT INTO lec(category_number,id,lec_name,regist_day,";
$sql .= "file_name,file_type,file_copied,teacher,level,time) values";
$sql .= "('$category_number','$id','$lec_name','$regist_day', ";
$sql .= "'$upfile_name','$upfile_type','$copied_file_name','$teacher','$level','$time')";

mysqli_query($conn, $sql);

mysqli_close($conn);

echo "<script>alert('강의 등록 완료'); location.href='http://test.hackers.com';</script>";

?>
