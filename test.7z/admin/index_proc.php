<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-08
 * Time: 오후 2:22
 */
//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

//실행할 쿼리
$sql_category = "select * from lec_category";
$sql_lec = "select * from lec";

//result에 쿼리값 저장
$result_category = mysqli_query($conn, $sql_category);
$result_lec = mysqli_query($conn, $sql_lec);


if(isset($_POST['lec_name']) && isset($_POST['categorySelection'])){
    if($_POST['lec_name'] == ""){
        echo "<script> alert('이름을 입력해 주세요1'); history.back();</script>";
        exit();
    }
    $lec_name = $_POST['lec_name'];
    $category_name = $_POST['categorySelection'];
    $sql2 = "INSERT INTO lec(lec_name,category_name) VALUES ('$lec_name','$category_name')";
    mysqli_query($conn, $sql2);
    echo "<script> history.back();</script>";
    exit();
}

if(isset($_POST['category_name'])){
    if($_POST['category_name'] == ""){
        echo "<script> alert('이름을 입력해 주세요2'); history.back();</script>";
        exit();
    }
    $category_name = $_POST['category_name'];
    $sql = "INSERT INTO lec_category(category_name) VALUES ('$category_name')";
    mysqli_query($conn, $sql);
    echo "<script> history.back();</script>";
    exit();
}

if(isset($_POST['number'])){
    $number = $_POST['number'];
    $sql2 = "DELETE FROM lec WHERE lec_number = '$number'";
    mysqli_query($conn, $sql2);
    echo "<script> history.back();</script>";
    exit();
}

$lec_name = $_POST['lec_name'];
$category_name = $_POST['categorySelection'];



//db연결 종료
mysqli_close();


