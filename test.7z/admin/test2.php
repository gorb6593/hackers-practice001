<?php include $_SERVER['DOCUMENT_ROOT']."/lecture_board/header.php";

$id = $_SESSION['userId'];
include $_SERVER['DOCUMENT_ROOT']."/admin/index_proc.php";
?>
<!DOCTYPE html>
<html>
<head>
    <script>
        $(document).ready(function(){
            $("#btn1").click(function(){
                $("#test1").text("Hello world!");
            });
            $("#btn2").click(function(){
                $("#test2").html("<b>Hello world!</b>");
            });
            $("#btn3").click(function(){
                $("#test3").val("Dolly Duck22");
            });
        });
    </script>
</head>
<body>

<p id="test1">This is a paragraph.</p>
<p id="test2">This is another paragraph.</p>

<p>Input field: <input type="text" id="test3" value="Mickey Mouse"></p>

<button id="btn1">Set Text</button>
<button id="btn2">Set HTML</button>
<button id="btn3">Set Value</button>

</body>
</html>