<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/admin/index_proc.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko" lang="ko">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" id="X-UA-Compatible" content="IE=EmulateIE8" />
    <title>해커스 HRD</title>
    <meta name="description" content="해커스 HRD" />
    <meta name="keywords" content="해커스, HRD" />

    <!-- 파비콘설정 -->
    <link rel="shortcut icon" type="image/x-icon" href="http://img.hackershrd.com/common/favicon.ico" />

    <!-- xhtml property속성 벨리데이션 오류/확인필요 -->
    <meta property="og:title" content="해커스 HRD" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="http://www.hackershrd.com/" />
    <meta property="og:image" content="http://img.hackershrd.com/common/og_logo.png" />

    <link type="text/css" rel="stylesheet" href="http://q.hackershrd.com/worksheet/css/common.css" />
    <link type="text/css" rel="stylesheet" href="http://q.hackershrd.com/worksheet/css/bxslider.css" />
    <link type="text/css" rel="stylesheet" href="http://q.hackershrd.com/worksheet/css/main.css" /><!-- main페이지에만 호출 -->
    <link type="text/css" rel="stylesheet" href="http://q.hackershrd.com/worksheet/css/sub.css" /><!-- sub페이지에만 호출 -->
    <link type="text/css" rel="stylesheet" href="http://q.hackershrd.com/worksheet/css/login.css" /><!-- login페이지에만 호출 -->

    <script type="text/javascript" src="http://q.hackershrd.com/worksheet/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="http://q.hackershrd.com/worksheet/js/plugins/bxslider/jquery.bxslider.min.js"></script>
    <script type="text/javascript" src="http://q.hackershrd.com/worksheet/js/plugins/bxslider/bxslider.js"></script>
    <script type="text/javascript" src="http://q.hackershrd.com/worksheet/js/ui.js"></script>
    <!--[if lte IE 9]> <script src="/js/common/place_holder.js"></script> <![endif]-->

</head>
<body>
<div id="wrap">
    <div id="container" class="container">
        <div id="content" class="content">
            <div class="tit-box-h3">
                <h3 class="tit-h3">강의카테고리 및 강의 등록</h3>
            </div>
            <form action="index_proc.php" method="post">
                <table border="0" cellpadding="0" cellspacing="0" class="tbl-col">
                    <caption class="hidden">강의정보</caption>
                    <colgroup>
                        <col style="width:15%"/>
                        <col style="*"/>
                    </colgroup>

                    <tbody>

                    <tr>

                    </tr>
                    <tr>
                        <th scope="col">강의 카테고리 추가</th>
                        <td>
                            <input type="text" name="category_name" placeholder="카테고리 이름을 입력하세요"/>
                            <input type="submit" name="c" value=" 카테고리 추가하기">
                        </td>
                    </tr>

                    </tbody>
                </table>
            </form>

            <form action="index_proc.php" method="post">
                <table border="0" cellpadding="0" cellspacing="0" class="tbl-col">
                    <caption class="hidden">강의정보</caption>
                    <colgroup>
                        <col style="width:15%"/>
                        <col style="*"/>
                    </colgroup>

                    <tbody>
                    <tr>
                        <th scope="col">카테고리</th>
                        <td>
                            <select class="input-sel" name="categorySelection" style="width:160px">
                                <option value="">현재 카테고리 목록</option>
                                <?php
                                while ($row_category = mysqli_fetch_array($result_category)) {
                                    ?>
                                    <option value="<?php echo $row_category['category_name']; ?>"><?php echo $row_category['category_name']; ?></option>
                                    <?php
                                }
                                ?>
                                <a href="index.php">수정/삭제</a>
                            </select>
                        </td>
                        </th>
                    </tr>
                    <tr>
                        <th scope="col">썸네일 파일</th>
                        <td>
                            <input type="submit" value="파일 추가하기">
                        </td>

                    </tr>
                    <tr>
                        <th scope="col">강의 제목</th>
                        <td>
                            <input type="text" class="input-text" name="lec_name"/>
                            <input type="submit" value="강의 추가하기">
                        </td>

                    </tr>
                    <tr>
                        <th scope="col">강의 목록</th>
                        <td>
                            <select class="input-sel" name="lectureSelection" style="width:160px">
                                <option value="">현재 강의 목록</option>
                                <?php
                                while ($row_lec = mysqli_fetch_array($result_lec)) {
                                    ?>
                                    <option value="<?php echo $row_lec['lec_name']; ?>"><?php echo "강의제목:".$row_lec['lec_name'].", 카테고리:".$row_lec['category_name']; ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </td>

                        </th>
                    </tr>
                    </tbody>
                </table>
            </form>
            <div class="box-btn t-r">
                <a href="" class="btn-m ml5">강의 수정/삭제하러 가기</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
