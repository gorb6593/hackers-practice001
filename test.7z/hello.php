<!DOCTYPE html>
<html>
<head>
</head>
<body>
hi <?php echo $_GET['name']; ?> welcome
you are in <?php echo $_GET['addr']; ?>
</body>
</html>
<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-01
 * Time: 오후 1:34
 */

?>

