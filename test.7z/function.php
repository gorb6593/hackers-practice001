<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-02
 * Time: 오전 8:57
 */
$str = "asljfnsj
dgnag";
echo $str;

echo strlen($str);
?>
<h2>strlen</h2>
<?php
echo  strlen($str);
?>
<h2>nl2br</h2>
<?php
echo nl2br($str);
?>
