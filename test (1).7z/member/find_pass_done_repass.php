<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-04
 * Time: 오후 6:12
 */
echo '1111111111111';
$pass1 = $_POST['pass1'];
$pass2 = $_POST['pass2'];
$id = $_POST['id'];
$no = $_POST['no'];

echo '<br>'.'pass1 :'.$pass1;
echo '<br>'.'pass2 :'.$pass2;
echo '<br>'.'id :'.$id;

if($pass1 != $pass2){
    //echo "<script>alert('아이디가 없습니다.');location.href='http://test.hackers.com/member/find_pass_done.php';</script>";
    echo "<script>alert('비밀번호가 일치하지 않습니다.'); history.back();</script>";
    exit();
}

//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$sql = "UPDATE MEMBER SET PASSWORD = SHA2('$pass1',256) WHERE NO = '$no'";

mysqli_query($conn,$sql);

mysqli_close($conn);

echo "<script>location.href='http://test.hackers.com';</script>";
exit();
?>