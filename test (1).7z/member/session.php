<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-04
 * Time: 오후 3:58
 */
$_SESSION['number'] = '123456';
echo $_SESSION['number'];
?>