<?php include $_SERVER['DOCUMENT_ROOT']."/common/header.php";

//include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$id = $_POST['id'];

if(isset($id)){
    $id = $_POST['id'];
}else{
    echo "<script>alert('아이디는 필수항목입니다.');location.replace('index.php?mode=step_03');</script>";
}

if(isset($_POST['name'])){
    $name = $_POST['name'];
}else{
    echo "<script>alert('이름은 필수항목입니다.');location.replace('index.php?mode=step_03');</script>";
}

$pw = $_POST['password'];
$pw2 = $_POST['password2'];

if($pw != $pw2){
    echo "<script>alert('비밀번호가 다릅니다. 확인해주세요.');location.replace('index.php?mode=step_03');</script>";
}
$password = hash('sha256', $pw, true);
$email = $_POST['email'].'@'.$_POST['email2'];
$tel = $_POST['tel1'].'-'.$_POST['tel2'].'-'.$_POST['tel3'];
$phone = $_POST['phone1'].'-'.$_POST['phone2'].'-'.$_POST['phone3'];
if(!isset($_POST['postcode'])){
    $postcode = '42000';
}else{
    $postcode = $_POST['postcode'];
}
$address = $_POST['address'];
$detail_address = $_POST['detail_address'];

$test = $_POST['sms'];
$sms = $test;

$test2 = $_POST['mail'];
$mail = $test2;

$__master  = '14.49.30.84:30007';
$__username = 'front_local';
$__password = 'dfrontend*@78';
$__database = 'test';

$conn = new mysqli($__master,$__username,$__password,$__database);

$sql = "insert into test.member(id,name,password,email,phone,tel,postcode,address,detail_address,sms_state,mail_state)
values ('$id','$name',sha2('$pw',256),'$email','$phone','$tel','$postcode','$address','$detail_address','$sms','$mail')";

mysqli_query($conn,$sql);

mysqli_close($conn);

echo "<script>location.href='http://test.hackers.com/member/index.php?mode=complete';</script>";
exit();
?>