<?php
$mode = $_GET['mode'];

$file_name = $mode.".php";

include_once $file_name;