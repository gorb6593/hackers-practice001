<?php include $_SERVER['DOCUMENT_ROOT']."/common/header.php";

//db 연결
include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$name = $_POST['name'];

$certification = $_POST['certification'];

if($certification == 'phone'){
    $phones = $_POST['phone'];
    $phone = $phones[0].'-'.$phones[1].'-'.$phones[2];

    //실행할 쿼리
    $sql_select = "select * from member where name = '$name' and phone = '$phone'";
}
if($certification == 'mail'){
    $mails = $_POST['email'];
    $mail = $mails[0].'@'.$mails[1];

    //실행할 쿼리
    $sql_select = "select * from member where name = '$name' and email = '$mail'";
}

/*
echo '<br> name :'.$name;
echo '<br> cert :'.$certification;
echo '<br>'.$phone;
*/

//result에 쿼리값 저장
$result = mysqli_query($conn, $sql_select);

//db연결 종료
mysqli_close();

//result값 출력
$row = mysqli_fetch_array($result);

if(isset($row['id'])){
    $id = $row['id'];
}else{
    echo "<script>alert('아이디가 없습니다');</script>";
    echo "<script>location.href='http://test.hackers.com/member/index.php?mode=find_id';</script>";
    exit();
}

?>
    <div id="container" class="container-full">
        <div id="content" class="content">
            <div class="inner">
                <div class="tit-box-h3">
                    <h3 class="tit-h3">아이디/비밀번호 찾기</h3>
                    <div class="sub-depth">
                        <span><i class="icon-home"><span>홈</span></i></span>
                        <strong>아이디/비밀번호 찾기</strong>
                    </div>
                </div>

                <ul class="tab-list">
                    <li class="on"><a href="#">아이디 찾기</a></li>
                    <li><a href="index.php?mode=find_pass">비밀번호 찾기</a></li>
                </ul>

                <div class="tit-box-h4">
                    <h3 class="tit-h4">아이디 조회결과</h3>
                </div>

                <div class="guide-box">
                    <p class="fs16 mb5">회원님의 아이디는 아래와 같습니다.</p>
                    <strong class="big-title tc-brand"><?php echo $id ?></strong>
                </div>

                <div class="box-btn mt30">
                    <a href="http://test.hackers.com/member/login.html" class="btn-l">로그인하러 가기</a>
                    <a href="index.php?mode=find_pass" class="btn-l-line ml5">비밀번호 찾기</a>
                </div>

            </div>
        </div>
    </div>
<?php include $_SERVER['DOCUMENT_ROOT']."/common/footer.php";
?>
</div>
</body>
</html>
