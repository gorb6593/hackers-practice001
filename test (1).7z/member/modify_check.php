<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2022-08-04
 * Time: 오전 10:27
 */

include $_SERVER['DOCUMENT_ROOT']."/member/db.php";

$no = $_POST['no'];
$name = $_POST['name'];
$pw = $_POST['password'];

if($pw[0] == $pw[1]){
    $password = $pw[0];
}else{
    //여기 못하고 있음
    echo "<script>alert('비밀번호가 다릅니다');</script>";
}
$emails = $_POST['email'];
$email = $emails[0].'@'.$emails[1];

$phones = $_POST['phone'];
$phone = $phones[0].'-'.$phones[1].'-'.$phones[2];

$tels = $_POST['tel'];
$tel = $tels[0].'-'.$tels[1].'-'.$tels[2];
$postcode = $_POST['postcode'];
$address = $_POST['address'];
$detail_address = $_POST['detail_address'];

if(isset($_POST['sms_state'])){
    $sms_state = 'Y';
}else{
    $sms_state = 'N';
}
if(isset($_POST['mail_state'])){
    $mail_state = 'Y';
}else{
    $mail_state = 'N';
}
/*
if(in_array('checked', $_POST['sms_state'])){
    $sms_state = 'Y';
}else if(in_array('unchecked', $_POST['sms_state'])){
    $sms_state = 'N';
}

if(in_array('checked', $_POST['mail_state'])){
    $mail_state = 'Y';
}else if(in_array('unchecked', $_POST['mail_state'])){
    $mail_state = 'N';
}
*/

/*
echo  '<br>'.'$no : '.$no;
echo  '<br>'.'$name : '.$name;
echo  '<br>'.'$password : '.$password;
echo  '<br>'.'$email : '.$email;
echo  '<br>'.'$phone : '.$phone;
echo  '<br>'.'$tel : '.$tel;
echo  '<br>'.'$postcode : '.$postcode;
echo  '<br>'.'$address : '.$address;
echo  '<br>'.'$detail_address : '.$detail_address;
echo  '<br>'.'$sms_state : '.$sms_state;
echo  '<br>'.'$mail_state : '.$mail_state;
*/

$sql_update = "update member
                  set name = '$name'
                    , password = '$password'
                    , email = '$email'
                    , phone = '$phone' 
                    , tel = '$tel' 
                    , postcode = '$postcode' 
                    , address = '$address' 
                    , detail_address = '$detail_address' 
                    , sms_state = '$sms_state' 
                    , mail_state = '$mail_state'
                where no = '$no'";

echo '<br>'.'업데이트 쿼리 작성';

mysqli_query($conn, $sql_update);

echo '<br>'.'db 업데이트 요청 끝 ';

mysqli_close();

echo  '<br>'.'db 연결 끝';

//메인화면으로 리다이렉트
header("Location: http://test.hackers.com");
exit();
?>